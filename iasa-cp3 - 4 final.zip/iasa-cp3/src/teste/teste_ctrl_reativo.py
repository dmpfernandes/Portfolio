# -*- coding: latin-1 -*-

import sys
sys.path.append("../lib")
sys.path.append("../agente_prospector")

import psa

#Definicao do agente prospector
from agente_prospector import AgenteProspector

#Definicao do controlo reactivo
from controlo_react.controlo_react import ControloReact
from controlo_react.reaccoes.recolher import Recolher as Comportamento

psa.iniciar("amb/amb1.das")

psa.executar(AgenteProspector(ControloReact(Comportamento())))
