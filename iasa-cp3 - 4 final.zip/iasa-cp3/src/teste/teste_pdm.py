# -*- coding: latin-1 -*-

import sys
sys.path.append("../lib")
sys.path.append("../agente_prospector")

import psa

#Definicao do agente prospector
from agente_prospector import AgenteProspector

#Definicao do controlo deliberativo
from controlo_delib.controlo_delib import ControloDelib
from plan.plan_pdm.plan_pdm import PlanPDM

psa.iniciar("amb/amb2.das", dinamb = 0.0)

psa.executar(AgenteProspector(ControloDelib(PlanPDM())))


#Visualizador:
#psa.vis(1).campo(dic_pod_valor)
#psa.vis(1).politica(politica)
#psa.vis(1).marcar(lista_pos, linha=1)
