# -*- coding: latin-1 -*-

import sys
sys.path.append("../lib")
sys.path.append("../agente_prospector")

import psa
from psa.agente import Agente
from psa.accao import Avancar
from psa.accao import Rodar
from psa.accao import Mover
from psa.actuador import ESQ
from psa.actuador import FRT
from psa.actuador import DIR

class AgenteTeste(Agente):
    def executar(self):
        self.actuador.actuar(Avancar())


psa.iniciar("amb/amb1.das")

psa.executar(AgenteTeste())
