# -*- coding: latin-1 -*-

import sys
sys.path.append("../lib")
sys.path.append("../agente_prospector")

import psa

#Definicao do agente prospector
from agente_prospector import AgenteProspector

#Definicao do controlo aprend
from controlo_aprend.controlo_aprend_ref import ControloAprendRef

psa.iniciar("amb/amb3.das", alvo_ini = True)

psa.executar(AgenteProspector(ControloAprendRef()))
