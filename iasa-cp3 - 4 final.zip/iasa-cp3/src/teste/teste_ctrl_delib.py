# -*- coding: latin-1 -*-

import sys
sys.path.append("../lib")
sys.path.append("../agente_prospector")

import psa

from pee.melhorprim.procura_aa import ProcuraAA as Procura

#Definicao do agente prospector
from agente_prospector import AgenteProspector

#Definicao do controlo deliberativo
from controlo_delib.controlo_delib import ControloDelib
from plan.plan_pee.plan_pee import PlanPEE

psa.iniciar("amb/amb2.das")

psa.executar(AgenteProspector(ControloDelib(PlanPEE(Procura()))))
