import psa5.actuador
from psa5.actuador import ESQ, DIR, FRT
