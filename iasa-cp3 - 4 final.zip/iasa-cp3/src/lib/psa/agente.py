import psa5.agente
from psa5.agente import Agente
