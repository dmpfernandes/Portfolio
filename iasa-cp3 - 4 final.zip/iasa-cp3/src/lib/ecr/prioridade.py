# -*- coding: latin-1 -*-
from comport_comp import ComportComp

class Prioridade(ComportComp): 

    def seleccionar_resposta(self, respostas):
        if respostas:
            return max(respostas, key = lambda resposta: resposta.prioridade)
