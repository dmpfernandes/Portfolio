# -*- coding: latin-1 -*-

class Resposta:

    def __init__(self, accao, prioridade=0):
        self.accao = accao
        self.prioridade = prioridade


    @property
    def accao(self):
        return self.accao

    @property
    def prioridade(self):
        return self.prioridade
