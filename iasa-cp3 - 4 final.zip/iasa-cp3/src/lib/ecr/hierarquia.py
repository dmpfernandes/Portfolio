# -*- coding: latin-1 -*-
from comport_comp import ComportComp

class Hierarquia(ComportComp):

    def seleccionar_resposta(self, respostas):
        if(respostas):
            return respostas[0]
