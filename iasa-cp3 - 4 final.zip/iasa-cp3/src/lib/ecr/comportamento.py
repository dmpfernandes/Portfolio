# -*- coding: latin-1 -*-

class Comportamento(object):

    def activar(self, percepcao):
        abstract
