
class ModeloPDM:

    def S(self):
        abstract

    def A(self, estado):
        abstract

    def T(self, s, a):
        abstract

    def R(self, s, a, sn):
        abstract
