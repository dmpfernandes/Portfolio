import psa
class PDM:

    def __init__(self, gama, delta_max):
        self._gama = gama
        self._delta_max = delta_max

    def utilidade(self, modelo):
        U = { s:0 for s in modelo.S()} # U inicial a 0

        while True:
            Uant = U.copy()
            delta = 0
            for s in modelo.S():
                U[s] = max(self.util_accao(s, a, Uant, modelo) for a in modelo.A(s))
                delta  = max(delta, abs(U[s] - Uant[s]))

            if delta < self._delta_max:
                break

        return U
        # Utilidade

    def util_accao(self, s, a, U, modelo):
        #somatorio das varias pesquisas

        #para o calculo precisamos:
        #trasicoes
        #recompensa
        #gama
        T = modelo.T
        R = modelo.R
        gama = self._gama

        #retornar uma soma #for para todos os s'
        # ou seja: somatorio de T(s,a,s')[R(s,a,s')+yU(s')]
        return sum(p * (R(s, a, sn) + gama * U[sn]) for (p,sn) in T(s,a))
        # double

    def politica(self, U, modelo):
        politicas = {}
        for s in modelo.S():
            politicas[s] = max(modelo.A(s), key=lambda a: self.util_accao(s, a, U, modelo))
        return politicas
        # Politica

    def resolver(self, modelo):
        U = self.utilidade(modelo)
        P = self.politica(U, modelo)
        return U, P
        #Tuple<E1->Utilidade,E2->Politica>
