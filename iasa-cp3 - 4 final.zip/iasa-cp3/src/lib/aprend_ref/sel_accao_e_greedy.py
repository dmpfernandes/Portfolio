
import random
from sel_accao import SelAccao
from memoria_aprend import MemoriaAprend

class SelAccaoEGreedy(SelAccao, MemoriaAprend):

    def __init__(self, mem_aprend, accoes, epsilon):
        self._mem_aprend = mem_aprend
        self._epsilon = epsilon
        self._accoes = accoes

    def seleccionar_accao(self, s):
        #selecionar se vai ter que usar o max acccao ou o explorar,
        #dependendo do valor do random
        numero_aleatorio = random.random()
        #print "numero_aleatorio: ",numero_aleatorio
        
        if numero_aleatorio > self._epsilon:
            #print "Fez accao Greedy"
            return self.max_accao(s)
        else:
            #print "Fez accao Explorar"
            return self.explorar(s)

    def max_accao(self, s):
        # max(self._accoes, key= funcao lambda)
        #greedy, quando tem ganho mantem a mesma accao
        return max(self._accoes, key = lambda a: self._mem_aprend.obter(s,a))

    def explorar(self, s):
        #choice as accoes
        return random.choice(self._accoes)
