
class SelAccao:

    def seleccionar_accao(self, s):
        abstract
