from aprend_ref import AprendRef

class AprendQ(AprendRef):

    def __init__(self, mem_aprend, sel_accao, alfa, gama):
        super(AprendQ, self).__init__(mem_aprend, sel_accao)
        self._gama = gama
        self._alfa = alfa

    def aprender(self, s, a, r, sn):
        #algoritmo Q-Learning
        #a parte do actualizar Q
        
        an = self._sel_accao.max_accao(sn)
        #print "sn: ",sn
        qsa = self._mem_aprend.obter(s, a)
        #print "qsa: ",qsa
        qsnan = self._mem_aprend.obter(sn, an)
        #print "qsnan: ",qsnan
        #print "r: ",r
        
        qsa += self._alfa * (r + (self._gama * (qsnan - qsa)))
        #print "qsa apos calculo: ", qsa
        self._mem_aprend.actualizar(s, a, qsa)
