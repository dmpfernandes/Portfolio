
from aprend_q import AprendQ

class AprendQE(AprendQ):

    def __init__(self, mem_aprend, sel_accao, alfa, gama, nsim):
        super(AprendQ, self).__init__(mem_aprend, sel_accao, alfa, gama)
        self._nsim = nsim #protected

    def aprender(self, s, a, r, sn):
        #void

    def _memorizar_episodio(self, s, a, r, sn):
        #void

    def simular(self):
        #void
