
from memoria_aprend import MemoriaAprend

class MemoriaEsparsa(MemoriaAprend):

    def __init__(self, valor_omissao = 0):
        self._valor_omissao = valor_omissao
        self._memoria = {} #dicionario, chaves estados accao, valores vao ser valores da funcao q

    @property
    def memoria(self):
        return self._memoria

    #verifica se existe a chave que e o par estado accao e
    def actualizar(self, s, a, q):
        self._memoria[(s,a)] = q

    def obter(self, s, a):
        return self._memoria.get((s,a), self._valor_omissao)
        #double
