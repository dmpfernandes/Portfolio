
class MemoriaAprend:
    
    def actualizar(self, s, a, q):
        abstract

    def obter(self, s, a):
        abstract
