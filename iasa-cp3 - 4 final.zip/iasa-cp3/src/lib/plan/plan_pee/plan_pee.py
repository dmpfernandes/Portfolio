
#from pee.mecproc.procura import Procura
from problema_plan import ProblemaPlan
from plan.planeador import Planeador

class PlanPEE(Planeador):

    def __init__(self, mec_pee):
        self._mec_pee = mec_pee
        self._plano = None

    def planear(self, modelo_plan, estado_inicial, objectivos):
        #planear para o primeiro objectivo
        problema = ProblemaPlan(estado_inicial, objectivos[0], modelo_plan.operadores())
        #print self._mec_pee
        solucao = self._mec_pee.resolver(problema)

        if solucao:
            self._plano = [passo_solucao.operador for passo_solucao in solucao[1:]]
        else:
            self.terminar_plano()

    def obter_accao(self, estado):
        if len(self._plano) != 0:
            operador = self._plano[0]
            self._plano.pop(0)
            return operador #Operador

    def plano_pendente(self):
        return len(self._plano) != 0

    def terminar_plano(self):
        self._plano = []
