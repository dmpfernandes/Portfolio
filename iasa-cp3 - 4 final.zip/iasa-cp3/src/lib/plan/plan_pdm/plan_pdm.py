
import psa
from plan.planeador import Planeador
from pdm.pdm import PDM
from modelo_pdm_plan import ModeloPDMPlan

class PlanPDM(Planeador, PDM):

    def __init__(self):
        self._gama = 0.95
        self._delta_max = 1.0
        self._utilidade = {}
        self._politica = {}

        self._pdm = PDM(self._gama, self._delta_max)

    def planear(self, modelo_plan, estado, objectivos):
        modelo = ModeloPDMPlan(modelo_plan, objectivos)
        self._utilidade, self._politica = self._pdm.resolver(modelo)
        psa.vis(1).campo(self._utilidade)
        psa.vis(1).politica(self._politica)

        if len(self._politica) == 0:
            self.terminar_plano()

        #void

    def obter_accao(self, s):
        return self._politica.get(s) #A(s).pop(0) #Operador

    def plano_pendente(self):
        #ver se existe politica
        return self._politica #boolean

    def terminar_plano(self):
        self._politica = {} #void
