from plan.modelo_plan import ModeloPlan
from pdm.modelo_pdm import ModeloPDM

class ModeloPDMPlan(ModeloPlan, ModeloPDM):

    def __init__(self, modelo_plan, objectivos):
        #S, A lista vazia
        self._S = []
        self._A = []

        #T, R dicionario
        # T(s, a) = [(p, s'), ...]
        self._T = {}
        self._R = {}

        self._rmax = 100

        self._objectivos = objectivos

        #chamar a funcao _iniciar_modelo
        self._iniciar_modelo(modelo_plan)

    def _iniciar_modelo(self, modelo_plan):
        self._S = modelo_plan.estados()
        self._A = modelo_plan.operadores() #operadores que representacao as accoes
        for s in self._S:
            for a in self._A:
                self._gerar_modelo(s, a)

    def _gerar_modelo(self, s, a):
        #sabemos as transicoes possiveis, por simulacao
        sn = a.aplicar(s)
        #pode nao existir transicao, entao
        if sn is None:
            #fica uma lista vazia
            self._T[(s, a)] = []
        else:
            #porque estamos a considerar um modelo nao determinista
            self._T[(s, a)] = [(1,sn)]
            self._R[(s, a, sn)] = self._gerar_recompensa(s, a, sn)

        #o _T(s,a) que esta a ser utilizado, esta de acordo com o dicionario,
        #que passa o estado e a accao, que esta numa lista de transicoes

    def _gerar_recompensa(self, s, a, sn):
        r = -a.custo(s,sn)
        #se o estado sn esta nos objetivos
        if sn in self._objectivos:
            r += self._rmax
        return r

    def estados(self):
        return self._S

    def operadores(self):
        return self._A


    def S(self):
        return self._S# lista de estados

    def A(self, estado):
        return self._A # lista de operadores

    def T(self, s, a):
        return self._T.get((s, a)) # lista de transicoes

    def R(self, s, a, sn):
        #modelo da recompensa
        return self._R.get((s, a, sn))
