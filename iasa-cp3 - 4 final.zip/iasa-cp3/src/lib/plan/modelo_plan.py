
class ModeloPlan:

    def estados(self):
        abstract

    def operadores(self):
        abstract
