

class Planeador:

    def planear(self, modelo_plan, estado_inicial, objectivos):
        abstract

    def obter_accao(estado):
        abstract

    def plano_pendente(self):
        abstract

    def terminar_plano(self):
        abstract
