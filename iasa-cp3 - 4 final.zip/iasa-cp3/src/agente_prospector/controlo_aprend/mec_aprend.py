import psa
from aprend_ref.memoria_esparsa import MemoriaEsparsa
from aprend_ref.aprend_q import AprendQ
from aprend_ref.sel_accao_e_greedy import SelAccaoEGreedy

class MecAprend:

    def __init__(self, accoes):
        self._accoes = accoes
        self._mem_aprend = MemoriaEsparsa()
        self._sel_accao = SelAccaoEGreedy(self._mem_aprend, self._accoes, 0.01) #epsilon 0.01
        self._aprend_ref = AprendQ(self._mem_aprend, self._sel_accao, 0.5, 0.9) #alfa 0.5 e gama 0.9

    def aprender(self, s, a, r, sn):
        self._aprend_ref.aprender(s, a, r, sn)#void
        psa.vis(1).aprendref(self._aprend_ref)

        

    def seleccionar_accao(self, s):
        return self._sel_accao.seleccionar_accao(s) #accao
