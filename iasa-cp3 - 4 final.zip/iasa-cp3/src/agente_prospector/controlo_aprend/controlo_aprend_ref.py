import psa.util #funcao
from psa.accao import Mover
from controlo import Controlo
from mec_aprend import MecAprend

class ControloAprendRef(Controlo):

    # usar o algoritmo SARSA

    def __init__(self):
        self._rmax = 100 #double

        #iniciamos o estado atual a None
        self._s = None #estado
        self._a = None #accao

        #angulos tem que ser absolutos
        self._accoes = [Mover(ang, ang_abs = True) for ang in psa.util.dirmov()]

        self._mec_aprend = MecAprend(self._accoes)

    def processar(self, percepcao):
        #atravez so selecionar acao sabemos o "a"
        # e atravez da percepcao posicao sabemos o "s"
        sn = percepcao.posicao
        an = self._mec_aprend.seleccionar_accao(sn)

        if (self._s is not None):
            r = self._gerar_reforco(percepcao)
            self._mec_aprend.aprender(self._s, self._a, r, sn)
            
        
        self._s = sn
        self._a = an
        return an
        #accao

    def _gerar_reforco(self, percepcao):
        r = -percepcao.custo_mov
        if percepcao.carga:
            r += self._rmax
        if percepcao.colisao:
            r -= self._rmax
        return r
        #double

