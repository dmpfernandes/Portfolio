# -*- coding: latin-1 -*-

class Controlo:

    def processar(self, percepcao):
        #raise NotImplementedError
        abstract
