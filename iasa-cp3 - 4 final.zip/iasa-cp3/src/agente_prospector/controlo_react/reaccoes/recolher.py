# -*- coding: latin-1 -*-

from ecr.hierarquia import Hierarquia

from aproximar_alvo import AproximarAlvo
from evitar_obst import EvitarObst
from contornar import Contornar
from explorar import Explorar

class Recolher(Hierarquia):

    def __init__(self):
        super(Recolher, self).__init__([AproximarAlvo(), EvitarObst(), Contornar(), Explorar()])
