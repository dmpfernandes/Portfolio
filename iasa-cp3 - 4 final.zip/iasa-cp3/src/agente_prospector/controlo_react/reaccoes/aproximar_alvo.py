# -*- coding: latin-1 -*-

from ecr.prioridade import Prioridade
from psa.actuador import FRT, ESQ, DIR
from aproximar_alvo_dir import AproximarAlvoDir

class AproximarAlvo(Prioridade):

    def __init__(self):
        super(AproximarAlvo, self).__init__([AproximarAlvoDir(ESQ), AproximarAlvoDir(FRT), AproximarAlvoDir(DIR)])
