# -*- coding: latin-1 -*-

from ecr.comportamento import Comportamento
from ecr.resposta import Resposta
from psa.accao import Mover
from psa.actuador import ESQ, FRT, DIR
from random import choice

class Explorar(Comportamento):

    def activar(self, percepcao):

        accao = choice([Mover(ESQ), Mover(FRT), Mover(DIR)])
        return Resposta(accao) # retorna uma resposta
