# -*- coding: latin-1 -*-
from ecr.reaccao import Reaccao 
from psa.accao import Mover
from ecr.resposta import Resposta

class AproximarAlvoDir(Reaccao):

    def __init__(self, direccao):
        self._direccao = direccao

    def _detectar_estimulo(self, percepcao):
        if percepcao[self._direccao].alvo:
            return percepcao[self._direccao].distancia #distancia ao alvo

    def _gerar_resposta(self, estimulo):
        accao = Mover(self._direccao)
        prioridade = 1.0/(1+estimulo)
        return Resposta(accao, prioridade)
