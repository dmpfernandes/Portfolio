# -*- coding: latin-1 -*-

from controlo import Controlo

class ControloReact(Controlo):

    def __init__(self, comportamento):
        self._comportamento = comportamento

    def processar(self, percepcao):
        resposta = self._comportamento.activar(percepcao)
        if resposta is not None:
            return resposta.accao
