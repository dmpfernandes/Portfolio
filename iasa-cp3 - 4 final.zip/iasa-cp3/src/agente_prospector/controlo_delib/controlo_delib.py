from plan.planeador import Planeador
from modelo_mundo import ModeloMundo

class ControloDelib:

    def __init__(self, planeador):
        self._planeador = planeador
        self._modelo_mundo = ModeloMundo()

    def _reconsiderar(self):
        return self._modelo_mundo.alterado or not self._objectivos or not self._planeador.plano_pendente()

    def _deliberar(self):
        elementos = [estado for estado in self._modelo_mundo.estados() if self._modelo_mundo.obter_elem(estado) == 'alvo']
        self._objectivos = elementos

    def _planear(self):
        if self._objectivos:
            self._planeador.planear(self._modelo_mundo, self._modelo_mundo.estado, self._objectivos)
        else:
            self._planeador.terminar_plano()

    def _executar(self):
        operador = self._planeador.obter_accao(self._modelo_mundo.estado) #Accao
        if operador:
            return operador.accao
        return None

    def processar(self, percepcao):
        self._assimilar(percepcao)

        if self._reconsiderar():
            self._deliberar()
            self._planear()

        return self._executar() # Accao

    def _assimilar(self, percepcao):
        self._modelo_mundo.actualizar(percepcao)
