

#psa.util :
#   mover(pos, ang)
#   dist(posini, posfin)

from psa import dirmov
#from psa.util import mover, dist
from operador_mover import OperadorMover
from plan.modelo_plan import ModeloPlan


class ModeloMundo(ModeloPlan):

    def __init__(self):
        self.alterado = True
        self._elementos = {}

        self._estado = None
        self._estados = [] #0..*

        #psa :
        #   dirmov(n=8)
        self._operadores = [OperadorMover(self, ang) for ang in dirmov()]

    @property
    def estado(self):
        return self._estado

    def obter_elem(self, estado):
        elemento = self._elementos.get(estado)
        #tipos de elementos:
            #'alvo'
            #'obst'
            #'vazio'
        if elemento is not None:
            return elemento #String

    def actualizar(self, percepcao):
        self._estado = percepcao.posicao
        if self._elementos != percepcao.imagem:
            self._elementos = percepcao.imagem # imagem -> String
            self._estados = percepcao.imagem.keys()
            self.alterado = True
        else:
            self.alterado = False

    def operadores(self):
        return self._operadores #List<E->Operador>

    def estados(self):
        return self._estados #List<E->Operador>
