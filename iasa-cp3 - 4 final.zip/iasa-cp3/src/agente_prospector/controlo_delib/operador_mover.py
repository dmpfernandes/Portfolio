

from psa.accao import Mover
from pee.modprob.operador import Operador
from psa.util import mover, dist

class OperadorMover(Operador):

    def __init__(self, modelo_mundo, ang):
        self._ang = ang
        self.accao = Mover(ang,ang_abs=True)
        self._modelo_mundo = modelo_mundo

    def aplicar(self, estado):
        novo_estado = mover(estado, self._ang) # Estado
        #tipos de elementos:
            #'alvo'
            #'obst'
            #'vazio'
        if self._modelo_mundo.obter_elem(novo_estado) in ['alvo', 'vazio']:
            return novo_estado

    def custo(self, estado, novo_estado):
        return dist(estado, novo_estado) # double

    @property
    def accao(self):
        return self.accao
